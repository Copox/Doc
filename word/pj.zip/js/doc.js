var dig = {
    key:0,
    tmpStr:'',
    defaultX:0,
    words:[
       /* {
            label:'apple',
            replaceWord:'apple{{0}}',
            value:0,
            p:true,
            lock:true
        }*/
    ],
    editor:{
        conditionTxt:'',
    },
    filter:{
        functions:[
            {
                label:'odd' 
            },
            {
                label:'even'
            },
            {
                label:'mod'
            },
            {
                label:'fill' 
            },
            {
                label:'reverse'
            },
            {
                label:'defX'
            },
            {
                label:'changeX'
            },
            {
                label:'pick'
            },
            {
                label:'lock'
            },
            {
                label:'unlock'
            }
        ],
        functionSelect:[],
        parameters:'',
        words:{
            lego:{
                bucket:[],
                picked:[],
                unPicked:[],
                all:[],
                btnState:{
                    all:{
                        raised:false,
                        type:'secondary'
                    },
                    picked:{
                        raised:false,   
                        type:'secondary'
                    },
                    unPicked:{
                        raised:false,
                        type:'secondary'
                    }
                },
                btns:{

                }
            },
            list:{
                picked:[],
                unPicked:[],
                all:[],
                btnState:{
                    all:{
                        raised:false,
                        type:'secondary'
                    },
                    picked:{
                        raised:false,   
                        type:'secondary'
                    },
                    unPicked:{
                        raised:false,
                        type:'secondary'
                    }
                }
            }
        },
    },
    output:{
        content:'Hello World !'
    },
    setting:{
        conditionTxt:'',
        content:'',
        result:'Happy Testing !'
    },
    menu:[
        {
            label:'About',
            v:false
        },
        {
            label: 'Help',
            v:false
        }
    ]
}



var app = new Vue({
    el: '#app',
    data:{
        dig
    },
    methods:{
        menuAbout:function(selected){
            if(selected.label === 'About'){
                dig.menu[0].v = dig.menu[0].v?false:true;
            }else{
                dig.menu[1].v = dig.menu[1].v?false:true;
            }
        },
        sliceStr:function(){

            func.words.reSet();
            var e = func.editor.getContents(quill);
            var conditionsTxt = dig.editor.conditionTxt.split('\n'),condition,o;
            for(var i in conditionsTxt){
                condition = func.regexper.sliceStr(conditionsTxt[i]);
                if(condition){
                   o = func.regexper.findStr(e.str,condition);
                   e.str = o.str;
                   e.result = e.result.concat(o.result);
                }
            }
            o = func.words.sliceStr(e);
            e.str = o.str;
            e.result = e.result.concat(o.result);
            func.words.upData(e);
        },
        legoColor:function(p){
            return p?'green':'red';
        },
        legoType:function(p){
            return p?'primary':'secondary';
        },
        changeWord:function(e){
            e.p = !e.p;
        },
        filterBtnsClick:function(t,e){
            if(e === 'all'){
                dig.filter.words[t].btnState.all.raised = (dig.filter.words[t].btnState.all.type = 'primary')&&true;
                dig.filter.words[t].btnState.picked.raised =  dig.filter.words[t].btnState.unPicked.raised = false;
                dig.filter.words[t].btnState.picked.type = dig.filter.words[t].btnState.unPicked.type = 'secondary';
                func.filter[t].updataAllWords();
            }else if(e === 'picked'){
                dig.filter.words[t].btnState.picked.raised = (dig.filter.words[t].btnState.picked.type = 'primary')&&true;
                dig.filter.words[t].btnState.all.raised = dig.filter.words[t].btnState.unPicked.raised = false;
                dig.filter.words[t].btnState.all.type = dig.filter.words[t].btnState.unPicked.type = 'secondary';
                func.filter[t].updataPickedWords();
            }else{
                dig.filter.words[t].btnState.unPicked.raised = (dig.filter.words[t].btnState.unPicked.type = 'primary')&&true;
                dig.filter.words[t].btnState.all.raised = dig.filter.words[t].btnState.picked.raised = false;
                dig.filter.words[t].btnState.all.type = dig.filter.words[t].btnState.picked.type = 'secondary';
                func.filter[t].updataUnPickedWords();
            }
            this.$refs[ t + 'Coll'].refreshHeight();
        },
        filterStr:function(){
            var valuesTxt = dig.filter.parameters.split('\n');
            var valuesCol = [];
            for(var i in valuesTxt){
                valuesCol.push(func.filter.values.partValues(valuesTxt[i]));
            }
            func.filter.filterWords(dig.filter.functionSelect,valuesCol);
        },
        combindStr:function(){
            if(dig.tmpStr && dig.words && dig.words.length){
                dig.output.content = func.words.makeUpStr(dig.tmpStr,dig.words,(word)=>{
                    if(word.p){
                        return '{{c' + ((word.x+1)?word.x:dig.defaultX) +  '::' + word.label + '}}';
                    }else{
                        return word.label;
                    }
                }).replace(/\{ \{ [0-9]+? \} \}/,(s)=>{ return s.split(' ').join('') });
                
            }
        },
        filterBtnsClicked:function(e){
            var x;
            switch (e.value) {
                case 0:
                x = parseInt(prompt("Please enter your X value"));
                x = (isNaN(x)||x===0)?undefined:x;
                e.word.x = x;
                    break;
                case 1:
                e.word.p = !e.word.p; 
                    break;
                case 2:
                case 3:
                e.word.lock = !e.word.lock;
                    break;
                default:
                    break;
            }
        },
        closeFilterBtnsDropdown:function(e){
            (this.$refs[e])[0].closeDropdown();
        }
    }
});

var quill = new Quill('#bubble-container', {
    placeholder: 'Put Something on here ...',
    theme: 'bubble',
    formats:['script'],
    modules: {
        toolbar: [{ 'script': 'sub'}, { 'script': 'super' }]
    }
});
quill.root.spellcheck = false;
quill.root.focus();
quill.root.blur();
quill.keyboard.addBinding({ key: 'Q', altKey: true }, (range, context)=>{
    if(context.format.script === 'sub'){
        quill.removeFormat(range);
    }else{
        this.quill.formatText(range,'script', 'sub');
    }
});
quill.keyboard.addBinding({ key: 'W', altKey: true }, (range, context)=>{
    if(context.format.script === 'super'){
        quill.removeFormat(range); 
    }else{
        this.quill.formatText(range,'script', 'super');
    }
});


/* core area */


var func = {
    regexper:{
        sliceStr:_partConditionalSentence,
        findStr:_findByConditionalSentence
    },
    editor:{
        getContents:_getContentsByQuill,
    },
    filter:{
        filterWords:_filterWords,
        values:{
            partValues:_partValues
        },
        list:{
            updataAllWords:_updataAllwordsList,
            updataPickedWords:_updataPickedWordsList,
            updataUnPickedWords:_updataUnPickedWordsList,
            resetAll:_restAllToList
        },
        lego:{
            updataAllWords:_updataAllwordsLego,
            updataPickedWords:_updataPickedWordsLego,
            updataUnPickedWords:_updataUnPickedWordsLego,
            resetAll:_restAllToLego
        },
        f:{
            odd:_modeOdd,
            even:_modeEven,
            mod:_modeMod,
            fill:_modeFill,
            reverse:_modeReverse,
            defX:_modeDefineX,
            changeX:_modeChangeX,
            pick:_modePick,
            lock:_modeLock,
            unlock:_modeUnLock
        }
    },
    words:{
        upData:_upDataToALL,
        reSet:_reSetALL,
        sliceStr:_partStrToWords,
        getAllWords:_getAllWords,
        getPickWords:_getPickWords,
        getBucketWords:_getBucketWords,
        makeUpStr:_makeUpString,
        toKey:_toKey
    }
}

function _partConditionalSentence(str){
    var p = {str:'',type:undefined,x:undefined};
    var i,j;
    if(str.length){
        i = str.match(/\[([0-9]),([0-9]+)\]/);
        j = str.match(/\{(.+)\}/i);
        if(i&&j&&i.length>=3){
            try { p.str = (new RegExp(j[1])).source; }catch(e){ 
                 console.log(e)
                 p.str = ''; }
            p.type = isNaN(parseInt(i[1]+1))?false:(parseInt(i[1])?true:false);
            p.x = isNaN(parseInt(i[2]+1))?undefined:parseInt(i[2]);
        }
    }
    console.log(p);
    return p;
} 

function _findByConditionalSentence(str,p,d,t){
    var e = {str:'',result:[]};
    var key = dig.key;
    if(p.str&&(p.type+1)){
       e.str = str.replace(new RegExp(p.str,'ig'),(s)=>{
            if(s.length === str.length){
                return s;
            }else{
                e.result.push({
                    label:s,
                    replaceWord:'{{'+ (++key) +'}}',
                    value:key,
                    p:(p.type?true:false),
                    lock:d?false:true,
                    x:(p.x+1)?p.x:undefined
                });
                return '{{' + key + '}}';
            }
       });
    }else{
        e.str = str;
    }
    if(!t) dig.key = key;  
    return e;
}


/* words function */

function _partStrToWords(e){
    if(e && e.str && e.str.length && e.result){
        return func.regexper.findStr(e.str,{str:'[a-zA-Z]\+',type:0},true);
    }else{
        return e;
    }
}

function _upDataToWords(words){
    if(words && words.length){
        dig.words = dig.words.concat(words);
        console.log(' updata ' + words.length +' word to words ');
    }else{
        console.log(' failed updata words ');
    }
}

function _upDataToTmpStr(str){
    if(str && str.length){
        dig.tmpStr = str;
        console.log('updata TmperString ');
    }else{
        console.log(' failed updata tmpStr ');
    }
}

function _upDataToALL(e){
    if(e && e.str&& e.str.length && e.result && e.result.length){
        console.log(' trying updata ALL ');
        _upDataToTmpStr(e.str);
        _upDataToWords(e.result);
        dig.filter.words.lego.bucket = func.words.getBucketWords(e.result);
        //app.$refs['legoColl'].refreshHeight();
        //app.$refs['listColl'].refreshHeight();
    }
}

function _reSetALL(){
    dig.key = 0;
    dig.words = [];
    dig.tmpStr = '';
    dig.filter.words.lego.bucket = [];
    dig.filter.words.list.btnState = {
        all:{
            raised:false,
            type:'secondary'
        },
        picked:{
            raised:false,
            type:'secondary'
        },
        unPicked:{
            raised:false,
            type:'secondary'
        }
    };
    dig.filter.words.lego.btnState = {
        all:{
            raised:false,
            type:'secondary'
        },
        picked:{
            raised:false,
            type:'secondary'
        },
        unPicked:{
            raised:false,
            type:'secondary'
        }
    };
    func.filter.list.resetAll();
    func.filter.lego.resetAll();
}

function _getAllWords(words){
    var o = [];
    for(var i in words){
        o.push(words[i]);
    }
    return o;
}

function _getPickWords(words,p){
    var o = [];
    for(var i in words){
        if(words[i].p == p){
            o.push(words[i]);
        }
    }
    return o;
}

function _getBucketWords(words){
    var o = []  ;
    for(var i in words){
        o[words[i].value] = words[i];
    }
    return o;
}

function _makeUpString(tmpStr,words,f){
    var str = tmpStr;
    if(tmpStr && tmpStr.length && words && words.length){
       for(var i in words){
           str = str.replace(words[i].replaceWord,f(words[i]));
       }
    }else{
        console.log('tmperString or words undefind');
    }
    return str;
}

function _toKey(str){
    var key = str;
    if(str){
        key = key.replace('{{','');
        key = key.replace('}}','');
        key = parseInt(key);
    }
    return isNaN(key)?undefined:key;
}

/* filter.list function */

function _updataAllwordsList(){
    func.filter.list.resetAll();
    var o = dig.words?dig.words:[];
    if(o && o.length){
        o =  func.words.getAllWords(o);
        dig.filter.words.list.all = o;
        console.log('updata filter.list all');
    }else{
        console.log('failed updata filter.list all');
    }
}

function _updataPickedWordsList(){
    func.filter.list.resetAll();
    var o = dig.words?dig.words:[];
    if(o && o.length){
        o =  func.words.getPickWords(o,true);
        dig.filter.words.list.picked = o;
        console.log('updata filter.list picked');
    }else{
        console.log('failed updata filter.list picked');
    }
}

function _updataUnPickedWordsList(){
    func.filter.list.resetAll();
    var o = dig.words?dig.words:[];
    if(o && o.length){
        o =  func.words.getPickWords(o,false);
        dig.filter.words.list.unPicked = o;
        console.log('updata filter.list unpicked');
    }else{
        console.log('failed updata filter.list unpicked');
    }
}

function _restAllToList(){
    dig.filter.words.list.unPicked =  [];
    dig.filter.words.list.picked = [];
    dig.filter.words.list.all = [];
}

/* filter.lego function */

function _updataAllwordsLego(){
    func.filter.lego.resetAll();
    var o = [];
    var strA,keyA;
    if(dig.tmpStr && dig.tmpStr.length){
        strA = dig.tmpStr.split(/\{\{[0-9]+?\}\}/g);
        keyA = dig.tmpStr.match(/\{\{[0-9]+?\}\}/g);
        keyA = keyA?keyA:[];

        if(strA.length){
            for(var i in strA){
                o.push({
                    str:strA[i],
                    key:func.words.toKey(keyA[i])
                });
            }
            console.log('updata logo all');
        }else{
            console.log('failed updata lego all , because str/key 0 length .');
        }
    }
    dig.filter.words.lego.all = o;
}

function _updataPickedWordsLego(){
    func.filter.lego.resetAll();
    var o = [];
    var strA,keyA;
    var unPickedWords = [], str = dig.tmpStr;
    if(dig.tmpStr && dig.tmpStr.length && dig.words && dig.words.length){
        for(var i in dig.words){
            if(!dig.words[i].p) unPickedWords.push(dig.words[i]);
        }
        str = func.words.makeUpStr(str,unPickedWords,(w)=>{
            return w.label;
        });

        strA = str.split(/\{\{[0-9]+?\}\}/g);
        keyA = str.match(/\{\{[0-9]+?\}\}/g);
        keyA = keyA?keyA:[];

        if(strA.length){
            for(var i in strA){
                o.push({
                    str:strA[i],
                    key:func.words.toKey(keyA[i])
                });
            }
            console.log('updata logo picked');
        }else{
            console.log('failed updata lego picked , because str/key 0 length .');
        }
    
    }
    dig.filter.words.lego.picked = o;
}

function _updataUnPickedWordsLego(){
    func.filter.lego.resetAll();
    var o = [];
    var strA,keyA;
    var unPickedWords = [], str = dig.tmpStr;
    if(dig.tmpStr && dig.tmpStr.length && dig.words && dig.words.length){
        for(var i in dig.words){
            if(dig.words[i].p) unPickedWords.push(dig.words[i]);
        }
        str = func.words.makeUpStr(str,unPickedWords,(w)=>{
            return w.label;
        });

        strA = str.split(/\{\{[0-9]+?\}\}/g);
        keyA = str.match(/\{\{[0-9]+?\}\}/g);
        keyA = keyA?keyA:[];

        if(strA.length){
            for(var i in strA){
                o.push({
                    str:strA[i],
                    key:func.words.toKey(keyA[i])
                });
            }
            console.log('updata logo picked');
        }else{
            console.log('failed updata lego picked , because str/key 0 length .');
        }
    
    }
    dig.filter.words.lego.unPicked = o;
}

function _restAllToLego(){
    dig.filter.words.lego.unPicked = [];
    dig.filter.words.lego.picked = [];
    dig.filter.words.lego.all = [];
    //dig.filter.words.lego.bucket = [];
}

/* filter function */
function _partValues(str){
    var i = [];
    if(str && str.length){
        i = str.match(/\{(.+)\}/i);
        if(i){
            i = i[1].split(',');
        }
    }
    return i;
}

function _filterWords(funcs,values){
    if(funcs && funcs.length){
        for(var i in funcs){
            if(func.filter.f[(funcs[i].label)]){
                func.filter.f[(funcs[i].label)](values[i]?values[i]:[]);
            }
        }
        console.log('all functions done');
    }
}

/* filter.functions */

function _modeOdd(v = []){
    var x = isNaN(parseInt(v[0]+1))?undefined:parseInt(v[0]);
    func.filter.f.mod([x,2],0);
}

function _modeEven(v = []){
    var x = isNaN(parseInt(v[0]+1))?undefined:parseInt(v[0]);
    func.filter.f.mod([x,2,1]);
}

function _modeMod(v = []){
    var x = isNaN(parseInt(v[0]+1))?undefined:parseInt(v[0]);
    var y = isNaN(parseInt(v[1]+1))?1:(parseInt(v[1])>0?parseInt(v[1]):1);
    var z = isNaN(parseInt(v[2]+1))?0:parseInt(v[2]);
    var words,o = {words:[],x:x};
    if(dig.words && dig.words.length){
        words = dig.words.filter(w => !w.lock );
        for(var i = (y + z - 1);i<words.length;i += y){
            words[i].p = true;
            words[i].x = x;
        }
        if(((y+z)%2)>0){
            words[0].p = true;
            words[0].x = x;
        }
        console.log('fucntion mod: mod '+ y);
    }
}

function _modeFill(v = []){
    //x , y , z
    var x = isNaN(parseInt(v[0]+1))?undefined:parseInt(v[0]);
    var y = isNaN(parseInt(v[1]+1))?0:parseInt(v[1]); // reverse
    var z = isNaN(parseInt(v[1]+1))?0:parseInt(v[1]); // lock
    var words,o = {words:[],x:x};
    if(dig.words && dig.words.length){
        words = dig.words;
        for(var i in words){
            if(z||!(words[i].lock)){
                words[i].x = words[i].p?words[i].x:x;
                    if(y){
                        words[i].p = !words[i].p;
                    }else{
                        words[i].p = true;
                    }
                }
        }
        console.log('function fill done');
    }
}

function _modeReverse(v = []){
    var x = isNaN(parseInt(v[0]+1))?undefined:parseInt(v[0]);
    var y = isNaN(parseInt(v[1]+1))?0:parseInt(v[1]);
    func.filter.f.fill([x,1,y]);
}

function _modeDefineX(v = []){
    var x = isNaN(parseInt(v[0]+1))?undefined:parseInt(v[0]);
    var y = isNaN(parseInt(v[1]+1))?0:parseInt(v[1]);// lock
    func.filter.f.changeX([x,undefined,y]);
}

function _modeChangeX(v =[]){
    var x = isNaN(parseInt(v[0]+1))?undefined:parseInt(v[0]);
    var y = isNaN(parseInt(v[1]+1))?undefined:parseInt(v[1]);
    var z = isNaN(parseInt(v[2]+1))?0:parseInt(v[1]);// lock
    var words;
    if(dig.words && dig.words.length){
        words = dig.words;
        for(var i in words){
            if(z||!(words[i].lock)){
                if(words[i].x === y){
                    words[i].x = x;
                }
            }
        }
        console.log('fucntion changeX done');
    }
}

function _modePick(v = []){
    var x = isNaN(parseInt(v[0]+1))?0:parseInt(v[0]); // reverse
    var y = isNaN(parseInt(v[1]+1))?0:parseInt(v[1]); // lock
    var words;
    if(dig.words && dig.words.length){
        words = dig.words;
        for(var i in words){
            if(y||!(words[i].lock)){
                if(x){
                        words[i].p = !words[i].p;
                    }else{
                        words[i].p = true;
                    }
            }
        }
        console.log('function pick done');
    }
}

function _modeLock(v = []){
    var x = isNaN(parseInt(v[0]+1))?0:parseInt(v[0]);
    var words;
    if(dig.words && dig.words.length){
        words = dig.words;
        for(var i in words){
            if(x){
                words[i].lock = !words[i].lock;
            }else{
                words[i].lock = true;
            }
        }
    }
}

function _modeUnLock(v = []){
    func.filter.f.lock([0]);
    func.filter.f.lock([1]);
}

/* editor function */

function _getContentsByQuill(q){
    var e = {str:'',result:[]};
    var key = dig.key,q = q.getContents(),ts = '';
    if(q.ops && q.ops.length){
        for(var i in q.ops){
            if(q.ops[i].attributes && q.ops[i].attributes.script){
                e.str += ('{{'+ (++key) +'}}');
                e.result.push({
                    label:q.ops[i].insert,
                    replaceWord:'{{'+ key +'}}',
                    value:key,
                    p:(q.ops[i].attributes.script==='sub'?true:false),
                    lock:true,
                    x:undefined
                });
            }else{
                ts = q.ops[i].insert.replace(/\{\{[0-9]+?\}\}/g,(s)=>{
                    return s.split('').join(' ');
                });
                e.str += ts;
            }
        }
    }
    dig.key = key;
    return e;
}

